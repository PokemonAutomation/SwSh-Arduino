/*  Pokemon Sword & Shield: Soft-Reset for Swords of Justice
 * 
 *  From: https://github.com/Mysticial/Pokemon-Automation-SwSh-Arduino-Scripts
 * 
 *      Please refer to the user manual for instructions and documentation.
 * 
 */

#include "Programs/SoftReset-SwordsOfJustice.h"

const uint16_t ENTER_CAMP_DELAY         =   7 * TICKS_PER_SECOND;
const uint16_t EXIT_CAMP_TO_RUN_DELAY   =   19 * TICKS_PER_SECOND;
const uint16_t RUN_DELAY                =   5 * TICKS_PER_SECOND;
