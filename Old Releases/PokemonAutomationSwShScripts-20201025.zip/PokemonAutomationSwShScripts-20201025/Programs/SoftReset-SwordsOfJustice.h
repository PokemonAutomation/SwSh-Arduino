/*  Pokemon Sword & Shield Arduino Programs
 * 
 *  From: https://github.com/Mysticial/Pokemon-Automation-SwSh-Arduino-Scripts
 * 
 */

#include <stdbool.h>
#include <stdint.h>
#include "Libraries/Settings.h"

extern const uint16_t ENTER_CAMP_DELAY;
extern const uint16_t EXIT_CAMP_TO_RUN_DELAY;
extern const uint16_t RUN_DELAY;
