/*  Pokemon Sword & Shield: Soft-Reset for Regis
 * 
 *  From: https://github.com/Mysticial/Pokemon-Automation-SwSh-Arduino-Scripts
 * 
 *      Please refer to the user manual for instructions and documentation.
 * 
 */

#include "Programs/SoftReset-Regi.h"

const uint16_t WAIT_TIME    =   12 * TICKS_PER_SECOND;
