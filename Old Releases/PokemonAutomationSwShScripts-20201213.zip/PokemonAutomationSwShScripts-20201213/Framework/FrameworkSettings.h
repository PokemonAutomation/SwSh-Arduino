/*  Framework Settings
 * 
 *  From: https://github.com/Mysticial/Pokemon-Automation-SwSh-Arduino-Scripts
 * 
 */

#ifndef PokemonAutomation_FrameworkSettings_H
#define PokemonAutomation_FrameworkSettings_H

#include <stdbool.h>
#include <stdint.h>

//  One second = 125 ticks. Thus each tick is 8 milliseconds.
//  Do not change this. This is a measured/callibrated number.
#define TICKS_PER_SECOND    125

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  General Options

//  The initial wait period before the program does anything. This gives you
//  time to switch the Arduino from computer to Switch if connected over a KVM.
extern const uint16_t CONNECT_CONTROLLER_DELAY;

//  Delay from pressing home anywhere in the settings to return to the home menu.
extern const uint16_t SETTINGS_TO_HOME_DELAY;

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  Board Type (for LEDs)

#define BOARD_TYPE_UNKNOWN      0
#define BOARD_TYPE_UNO          1
#define BOARD_TYPE_TEENSY2      2

extern const int BOARD_TYPE;

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  User Callbacks

void start_program_callback(void);
void end_program_callback(void);

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
#endif
