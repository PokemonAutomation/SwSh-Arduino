/*  Pokemon Sword & Shield: Beam Resetter
 * 
 *  From: https://github.com/Mysticial/Pokemon-SwSh-Arduino-Scripts
 * 
 *      Please refer to the user manual for instructions and documentation.
 * 
 */

#include "Programs/MultiGameFossil.h"



//
//  The list of participating saves. Each entry in the array will have 3 parameters:
//
//  Parameter 1:    The slot # of the user. (1 is the left-most user, 2 is the 2nd-to-left, etc...)
//  Parameter 2:    Dracozolt, Arctozolt, Dracovish, or Arctovish
//  Parameter 3:    The number of revives to perform.
//
//  To state the obvious: DO NOT specify the same user-slot twice as it will double-save.
//
const Batch BATCH[] = {
    {3, Arctozolt, 960},
    {6, Arctozolt, 960},
//    {2, Dracozolt, 240},
//    {2, Dracozolt, 480},
//    {6, Dracovish, 960},



    //  DO NOT DELETE THIS
    {0},
};


