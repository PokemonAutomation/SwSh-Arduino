/*  Pokemon Sword & Shield Arduino Programs
 * 
 *  From: https://github.com/Mysticial/Pokemon-SwSh-Arduino-Scripts
 * 
 */

#include <stdbool.h>
#include <stdint.h>

extern const uint8_t SKIPS;

//  View the rolled pokemon for this long before resetting.
extern const uint16_t VIEW_TIME;
