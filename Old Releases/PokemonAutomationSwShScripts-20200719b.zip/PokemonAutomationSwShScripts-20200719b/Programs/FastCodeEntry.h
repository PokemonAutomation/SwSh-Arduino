/*  Pokemon Sword & Shield Arduino Programs
 * 
 *  From: https://github.com/Mysticial/Pokemon-SwSh-Arduino-Scripts
 * 
 */

#include <stdbool.h>
#include <stdint.h>


//  Raid Code
extern const char* RAID_CODE;
