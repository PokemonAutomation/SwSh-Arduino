/*  Pokemon Sword & Shield Arduino Programs
 * 
 *  From: https://github.com/Mysticial/Pokemon-SwSh-Arduino-Scripts
 * 
 */

#include <stdbool.h>
#include <stdint.h>

typedef enum{
    Dracozolt   =   0,
    Arctozolt   =   1,
    Dracovish   =   2,
    Arctovish   =   3,
} FossilMon;
typedef struct{
    uint8_t game_slot;
    FossilMon mon;
    uint16_t revives;
} Batch;


//
//  The list of participating saves. Each entry in the array will have 3 parameters:
//
//  Parameter 1:    The slot # of the user. (1 is the left-most user, 2 is the 2nd-to-left, etc...)
//  Parameter 2:    The pokemon you are reviving in this save.
//  Parameter 3:    The number of revives to perform.
//
//  To state the obvious: DO NOT specify the same user-slot twice as it will double-save.
//
extern const Batch BATCH[];


