/*  Pokemon Sword & Shield Arduino Programs
 * 
 *  From: https://github.com/Mysticial/Pokemon-SwSh-Arduino-Scripts
 * 
 */

#include <stdbool.h>
#include <stdint.h>

//  The maximum number of skips to perform.
//  The actual # of skips will be lower if any errors are made.
extern const uint32_t skips;



////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  Advanced Settings (you shouldn't need to change these)

//  Run auto-recovery every this # of skips.
//  At 500, the overhead is approximately 0.5%.
extern const uint16_t CORRECTION_SKIPS;


