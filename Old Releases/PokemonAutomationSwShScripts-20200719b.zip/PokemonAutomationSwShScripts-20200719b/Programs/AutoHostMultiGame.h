/*  Pokemon Sword & Shield Arduino Programs
 * 
 *  From: https://github.com/Mysticial/Pokemon-SwSh-Arduino-Scripts
 * 
 */

#include <stdbool.h>
#include <stdint.h>


//  Raid Code
//      No code:            RANDOM_DIGITS = 0       RAID_CODE = ""
//      Fixed code:         RANDOM_DIGITS = 0       RAID_CODE = "12345678"
//      Random Code:        RANDOM_DIGITS = 4       RAID_CODE = "12345678"
//
//  "RANDOM_DIGITS" specifies how many of the first digits are randomized.
//  If it is less than 8, the remaining digits will be copies of the last digit.
//  This makes it easier to enter the code.
//
//  When using random codes, "RAID_CODE" is used to generate the starting seed.
extern const uint8_t RANDOM_DIGITS;
extern const char* RAID_CODE;


//  General Settings
extern const char HOST_ONLINE;              //  true = host online, false = host offline
extern const uint16_t LOBBY_WAIT_DELAY;     //  3:00 - 60 secs = 2:00


//  Game List
typedef struct{
    uint8_t game_slot;          //  Game slot at start of program. (must be 1 or 2)
    uint8_t user_slot;          //  User # to host from.

    uint8_t skips;              //  # of frame skips to roll before hosting.
    bool accept_FRs;            //  Accept friend requests.

    uint8_t move_slot;          //  If 0, don't select a move. Otherwise select this move slot.
    bool dynamax;               //  If 1st move select is enabled, dynamax as well.

    uint16_t post_raid_delay;   //  Extra wait time after each raid.
} RollingAutoHostSlot;
extern const RollingAutoHostSlot GAME_LIST[];


//  Increase these if your internet is slow.
extern const uint16_t CONNECT_TO_INTERNET_DELAY;    //  Time from "Connect to Internet" to when you're ready to enter den.
extern const uint16_t ENTER_ONLINE_DEN_DELAY;       //  "Communicating" when entering den while online.
extern const uint16_t START_RAID_DELAY;             //  Delay from "Invite Others" to when the clock starts ticking.

extern const uint16_t RAID_START_TO_EXIT_DELAY;     //  Time from start raid to reset. (when not selecting move)
extern const uint16_t DELAY_TO_SELECT_MOVE;         //  This + RAID_START_TO_EXIT_DELAY = time from start raid to select move.


