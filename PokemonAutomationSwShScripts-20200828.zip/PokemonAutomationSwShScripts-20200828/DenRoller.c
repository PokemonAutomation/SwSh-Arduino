/*  Pokemon Sword & Shield: Den Roller
 * 
 *  From: https://github.com/Mysticial/Pokemon-SwSh-Arduino-Scripts
 * 
 *      Please refer to the user manual for instructions and documentation.
 * 
 */

#include "Libraries/Settings.h"
#include "Programs/DenRoller.h"



//  # of frames to roll.
const uint8_t SKIPS         =   3;

//  View the rolled pokemon for this long before resetting.
const uint16_t VIEW_TIME    =   5 * TICKS_PER_SECOND;


