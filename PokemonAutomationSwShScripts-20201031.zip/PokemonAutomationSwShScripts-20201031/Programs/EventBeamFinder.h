/*  Pokemon Sword & Shield Arduino Programs
 * 
 *  From: https://github.com/Mysticial/Pokemon-Automation-SwSh-Arduino-Scripts
 * 
 */

#include <stdbool.h>
#include <stdint.h>

//  View the den for this duration before moving on.
extern const uint16_t WAIT_TIME_IN_DEN;


