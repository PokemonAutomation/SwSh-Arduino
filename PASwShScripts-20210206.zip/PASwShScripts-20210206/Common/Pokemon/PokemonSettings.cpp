
#include "PokemonSettings.c"
