/*  Shared Routines for Program Flow
 * 
 *  From: https://github.com/Mysticial/Pokemon-SwSh-Arduino-Scripts
 * 
 */

#ifndef SwitchController_OnboardLED_H
#define SwitchController_OnboardLED_H

#include <stdbool.h>

void onboard_led(bool on);
void setup_leds(void);


#endif
