/*  Pokemon Sword & Shield: Turbo A
 * 
 *  From: https://github.com/Mysticial/Pokemon-SwSh-Arduino-Scripts
 * 
 *      Please refer to the user manual for instructions and documentation.
 * 
 */

#include "Programs/TurboA.h"



//  Attempt to dodge the system update window if it's there.
const bool DODGE_SYSTEM_UPDATE_WINDOW   =   true;

