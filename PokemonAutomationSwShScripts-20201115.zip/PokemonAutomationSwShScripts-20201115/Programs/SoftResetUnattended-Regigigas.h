/*  Pokemon Sword & Shield Arduino Programs
 * 
 *  From: https://github.com/Mysticial/Pokemon-Automation-SwSh-Arduino-Scripts
 * 
 */

#include <stdbool.h>
#include <stdint.h>
#include "Libraries/Settings.h"


//  This needs to be carefully calibrated.
//    - If it's too short, it may stop on a non-shiny.
//    - If it's too long, it may run from a shiny.
//
//  There is less than a 0.5 second window which this must land in.
//
//  The default value here is calibrated for the "average system". If it doesn't
//  work, then you must calibrate it yourself.
//
extern const uint16_t START_TO_ATTACK_DELAY;

//  Time to return to the overworld after selecting a move.
extern const uint16_t END_BATTLE_DELAY;
