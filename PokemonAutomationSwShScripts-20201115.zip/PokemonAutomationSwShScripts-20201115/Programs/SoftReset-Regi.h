/*  Pokemon Sword & Shield Arduino Programs
 * 
 *  From: https://github.com/Mysticial/Pokemon-Automation-SwSh-Arduino-Scripts
 * 
 */

#include <stdbool.h>
#include <stdint.h>
#include "Libraries/Settings.h"

extern const uint16_t WAIT_TIME;
