# NativePrograms

Source code for the Arduino-side programs.

## How to Build

[See the manual.](../..//Documentation/HowToUse.md#building-the-hex-files)
