/*  Onboard LEDs
 * 
 *  From: https://github.com/Mysticial/Pokemon-Automation-SwSh-Arduino-Scripts
 * 
 */

#ifndef SwitchController_OnboardLED_H
#define SwitchController_OnboardLED_H

#include <stdbool.h>

void setup_leds(void);
void onboard_led(bool on);


#endif
