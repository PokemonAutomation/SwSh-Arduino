/*  Pokemon Sword & Shield: Softlock Auto-Host (Friend Search Method)
 * 
 *  From: https://github.com/Mysticial/Pokemon-Automation-SwSh-Arduino-Scripts
 * 
 *      Please refer to the user manual for instructions and documentation.
 * 
 */

#include "Libraries/Settings.h"
#include "Programs/AutoHostFriendSearch.h"



//  Raid Code
//      No code:            RANDOM_DIGITS = 0       RAID_CODE = ""
//      Fixed code:         RANDOM_DIGITS = 0       RAID_CODE = "1234 5678"
//      Random Code:        RANDOM_DIGITS = 4       RAID_CODE = "1234 5678"
//
//  Non-digit characters (such as spaces or hyphen) will be skipped.
//
//  "RANDOM_DIGITS" specifies how many of the first digits are randomized.
//  If it is less than 8, the remaining digits will be copies of the last digit.
//  This makes it easier to enter the code.
//
//  When using random codes, "RAID_CODE" is used to generate the starting seed.
const uint8_t RANDOM_DIGITS     =   0;
const char* RAID_CODE           =   "1280 0000";


//  Is the Pokemon catchable?
const bool CATCHABLE    =   true;


//  Accept Friend Requests
const bool ACCEPT_FRIEND_REQUESTS   =   true;

//  User Slot Position:
//      This number is the slot position of the user at the top of the Home menu.
//  The left-most user is slot 1. This must be set correctly to properly accept
//  FRs and to successfully disconnect from the raid.
const uint8_t USER_SLOT             =   1;


//  Additional Raid Delay:
//      If you are farming a pokemon and the time between raids is too short to
//  join consecutive raids, use this to add time between raids. This extra wait
//  time is done after entering the den, but before entering the code.
const uint16_t EXTRA_DELAY_BETWEEN_RAIDS    =   0 * TICKS_PER_SECOND;


//  Start the raid before 3:00.
//
//  This is a dangerous option that lets you start the raid before 3:00.
//  If the raid starts empty, it will not be able to airplane out of the raid.
//  Thus it can clear by itself and destroy the den.
//
//  By default, this is set to 180 seconds to wait out the entire 3:00 timer.
//  If you set it less than that, you MUST keep an eye on the program.
//  Be ready to kill the program if a raid goes empty.
const uint16_t LOBBY_WAIT_DELAY     =   180 * TICKS_PER_SECOND;


//  Rollover Prevention
//
//  If set to zero, this feature is disabled.
//  Otherwise, the program will touch the date at roughly this interval to
//  prevent the den from rolling over. This feature requres time-sync be disabled.
const uint32_t TOUCH_DATE_INTERVAL  =   (uint32_t)4 * 3600 * TICKS_PER_SECOND;  //  4 hours



//  Increase these if your internet is slow.
const uint16_t CONNECT_TO_INTERNET_DELAY    =   20 * TICKS_PER_SECOND;  //  Time from "Connect to Internet" to when you're ready to enter den.
const uint16_t ENTER_ONLINE_DEN_DELAY       =   8 * TICKS_PER_SECOND;   //  "Communicating" when entering den while online.
const uint16_t OPEN_ONLINE_DEN_LOBBY_DELAY  =   8 * TICKS_PER_SECOND;   //  Delay from "Invite Others" to when the clock starts ticking.

const uint16_t RAID_START_TO_EXIT_DELAY     =   14 * TICKS_PER_SECOND;  //  Time from start of raid to airplane out.
const uint16_t EXIT_WAIT_DELAY              =   32 * TICKS_PER_SECOND;  //  Time from airplane out to return to overworld.


