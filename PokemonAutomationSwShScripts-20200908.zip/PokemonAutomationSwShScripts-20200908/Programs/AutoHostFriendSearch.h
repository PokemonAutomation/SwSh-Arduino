/*  Pokemon Sword & Shield Arduino Programs
 * 
 *  From: https://github.com/Mysticial/Pokemon-SwSh-Arduino-Scripts
 * 
 */

#include <stdbool.h>
#include <stdint.h>


//  Raid Code
//      No code:            RANDOM_DIGITS = 0       RAID_CODE = ""
//      Fixed code:         RANDOM_DIGITS = 0       RAID_CODE = "12345678"
//      Random Code:        RANDOM_DIGITS = 4       RAID_CODE = "12345678"
//
//  "RANDOM_DIGITS" specifies how many of the first digits are randomized.
//  If it is less than 8, the remaining digits will be copies of the last digit.
//  This makes it easier to enter the code.
//
//  When using random codes, "RAID_CODE" is used to generate the starting seed.
extern const uint8_t RANDOM_DIGITS;
extern const char* RAID_CODE;


//  Accept Friend Requests
extern const bool ACCEPT_FRIEND_REQUESTS;

//  User Slot Position:
//      This number is the slot position of the user at the top of the Home menu.
//  The left-most user is slot 1. This must be set correctly to properly accept
//  FRs and to successfully disconnect from the raid.
extern const uint8_t USER_SLOT;


//  Additional Raid Delay:
//      If you are farming a pokemon and the time between raids is too short to
//  join consecutive raids, use this to add time between raids. This extra wait
//  time is done after the code is entered, but before opening the lobby.
extern const uint16_t EXTRA_DELAY_BETWEEN_RAIDS;


//  Start the raid before 3:00.
//
//  This a dangerous option that lets you start the raid before 3:00.
//  If the raid starts empty, it will not be able to airplane out of the raid.
//  Thus it can clear by itself and destroy the den.
//
//  By default, this is set to 180 seconds to wait out the entire 3:00 timer.
//  If you set it less than that, you MUST keep and eye on the program.
//  Be ready to kill the program if a raid goes empty.
extern const uint16_t LOBBY_WAIT_DELAY;


//  Rollover Prevention
//
//  If set to zero, this feature is disabled.
//  Otherwise, the program will touch the date at roughly this interval to
//  prevent the den from rolling over. This feature requres time-sync be disabled.
extern const uint32_t TOUCH_DATE_INTERVAL;



//  Increase these if your internet is slow.
extern const uint16_t CONNECT_TO_INTERNET_DELAY;    //  Time from "Connect to Internet" to when you're ready to enter den.
extern const uint16_t ENTER_ONLINE_DEN_DELAY;       //  "Communicating" when entering den while online.
extern const uint16_t START_RAID_DELAY;             //  Delay from "Invite Others" to when the clock starts ticking.

extern const uint16_t RAID_START_TO_EXIT_DELAY;     //  Time from start of raid to airplane out.
extern const uint16_t EXIT_WAIT_DELAY;              //  Time from airplane out to return to overworld.


