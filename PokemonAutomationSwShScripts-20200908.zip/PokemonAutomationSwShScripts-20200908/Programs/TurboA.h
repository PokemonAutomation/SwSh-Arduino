/*  Pokemon Sword & Shield Arduino Programs
 * 
 *  From: https://github.com/Mysticial/Pokemon-SwSh-Arduino-Scripts
 * 
 */

#include <stdbool.h>
#include <stdint.h>

//  Attempt to dodge the system update window if it's there.
const bool DODGE_SYSTEM_UPDATE_WINDOW;


