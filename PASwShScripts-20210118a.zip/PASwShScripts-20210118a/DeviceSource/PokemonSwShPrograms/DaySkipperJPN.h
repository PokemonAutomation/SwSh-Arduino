/*  Pokemon Sword & Shield Arduino Programs
 * 
 *  From: https://github.com/Mysticial/Pokemon-Automation-SwSh-Arduino-Scripts
 * 
 */

#include "CommonFramework/ControllerDefs.h"


//  The maximum number of skips to perform.
//  The actual # of skips will be lower if any errors are made.
extern const uint32_t skips;


////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  Advanced Settings (you shouldn't need to change these)

//  Run auto-recovery every this # of skips. Zero disables the auto-corrections.
//  At 500, the overhead is approximately 0.5%.
extern const uint16_t CORRECTION_SKIPS;


