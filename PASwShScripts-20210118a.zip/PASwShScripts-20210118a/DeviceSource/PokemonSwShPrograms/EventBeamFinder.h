/*  Pokemon Sword & Shield Arduino Programs
 * 
 *  From: https://github.com/Mysticial/Pokemon-Automation-SwSh-Arduino-Scripts
 * 
 */

#include "CommonFramework/ControllerDefs.h"


//  View the den for this duration before moving on.
extern const uint16_t WAIT_TIME_IN_DEN;


