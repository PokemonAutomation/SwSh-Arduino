/*  Device-side Callbacks for the Pokemon Programs
 * 
 *  From: https://github.com/Mysticial/Pokemon-Automation-SwSh-Arduino-Scripts
 * 
 */

#include <stdint.h>

void dayskipper_on_skip_callback(uint32_t remaining_skips);
