The PDF manual no longer exists. Please use the online documentation.

https://github.com/Mysticial/Pokemon-Automation-SwSh-Arduino-Scripts/blob/master/Documentation/README.md
