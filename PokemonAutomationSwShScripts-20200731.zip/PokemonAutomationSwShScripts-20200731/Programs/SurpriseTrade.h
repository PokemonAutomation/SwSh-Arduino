/*  Pokemon Sword & Shield Arduino Programs
 * 
 *  From: https://github.com/Mysticial/Pokemon-SwSh-Arduino-Scripts
 * 
 */

#include <stdbool.h>
#include <stdint.h>

extern const uint8_t BOXES_TO_TRADE;



////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//  Advanced Settings (you shouldn't need to change these)

extern const uint16_t INITIAL_WAIT;
extern const uint16_t TRADE_ANIMATION;
extern const uint16_t EVOLVE_DELAY;


