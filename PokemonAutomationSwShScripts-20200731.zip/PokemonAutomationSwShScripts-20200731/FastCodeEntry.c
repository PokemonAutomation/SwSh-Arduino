/*  Pokemon Sword & Shield: Fast Code Entry
 * 
 *  From: https://github.com/Mysticial/Pokemon-SwSh-Arduino-Scripts
 * 
 *      Please refer to the user manual for instructions and documentation.
 * 
 */

#include "Programs/FastCodeEntry.h"



//  Raid Code
const char* RAID_CODE = "9107 3091";
