/*  Pokemon Sword & Shield Arduino Programs
 * 
 *  From: https://github.com/Mysticial/Pokemon-Automation-SwSh-Arduino-Scripts
 * 
 */

#include <stdbool.h>
#include <stdint.h>

//  Wait in the Home menu for this long before resetting the game.
extern const uint16_t DELAY_BEFORE_RESET;


